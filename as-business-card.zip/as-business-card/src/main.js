// Визитка A/S — статическая страница, дополнительных библиотек не требуется.
// Все Telegram-ссылки и тексты редактируются в index.html.

const year = document.querySelector('.footer span:last-child');
if (year) year.textContent = `© ${new Date().getFullYear()}`;
